from spire.xls import *
from spire.xls.common import *
import re
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
import threading
import os

def make_autopct(values):
    def my_autopct(pct):
        total = sum(values)
        val = int(round(pct * total / 100.0))
        return f"{pct:.1f}%\n({val})"
    return my_autopct

class GraphViewer(tk.Toplevel):
    def __init__(self, parent, figures):
        super().__init__(parent)
        self.title("Graphiques Renouvellement PC 2025")
        self.figures = figures
        self.index = 0

        self.canvas = FigureCanvasTkAgg(self.figures[self.index], master=self)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        btn_frame = tk.Frame(self)
        btn_frame.pack(fill=tk.X, pady=5)
        self.prev_btn = tk.Button(btn_frame, text="⬅️ Précédent", command=self.prev_fig)
        self.prev_btn.pack(side=tk.LEFT, padx=10)
        self.next_btn = tk.Button(btn_frame, text="Suivant ➡️", command=self.next_fig)
        self.next_btn.pack(side=tk.RIGHT, padx=10)
        self.bind("<Left>", lambda e: self.prev_fig())
        self.bind("<Right>", lambda e: self.next_fig())
        self.focus_set()
        self.update_buttons()

    def show_fig(self):
        self.canvas.get_tk_widget().pack_forget()
        self.canvas = FigureCanvasTkAgg(self.figures[self.index], master=self)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.canvas.draw()
        self.update_buttons()

    def prev_fig(self):
        if self.index > 0:
            self.index -= 1
            self.show_fig()

    def next_fig(self):
        if self.index < len(self.figures) - 1:
            self.index += 1
            self.show_fig()

    def update_buttons(self):
        self.prev_btn.config(state=tk.NORMAL if self.index > 0 else tk.DISABLED)
        self.next_btn.config(state=tk.NORMAL if self.index < len(self.figures) - 1 else tk.DISABLED)

def afficher_graphiques(mois_uniques, valeurs_portables, valeurs_fixes, win10, win11, stats_regions, win10_par_num, win11_par_num, titre_fichier=None, stats_globales=None):
    figures = []

    # Titre du fichier si fourni
    if titre_fichier:
        fig_title, ax_title = plt.subplots(figsize=(6, 1))
        ax_title.axis('off')
        ax_title.text(0.5, 0.5, f"Fichier : {titre_fichier}", va='center', ha='center', fontsize=12, fontweight='bold')
        fig_title.tight_layout()
        figures.append(fig_title)

    # 📊 Barres comparatives
    x = range(len(mois_uniques))
    fig1, ax1 = plt.subplots()
    ax1.bar(x, valeurs_portables, width=0.4, label="Portables 💻", color='blue')
    ax1.bar([i + 0.4 for i in x], valeurs_fixes, width=0.4, label="Fixes 🖥️", color='orange')
    ax1.set_xticks([i + 0.2 for i in x])
    ax1.set_xticklabels(mois_uniques)
    ax1.set_title("Renouvellement PC 2025 - Répartition mensuelle")
    ax1.set_xlabel("Mois")
    ax1.set_ylabel("Nombre")
    ax1.legend()
    for i, v in enumerate(valeurs_portables):
        ax1.text(i, v + 0.5, str(v), ha='center', color='blue', fontweight='bold')
    for i, v in enumerate(valeurs_fixes):
        ax1.text(i + 0.4, v + 0.5, str(v), ha='center', color='darkorange', fontweight='bold')
    fig1.tight_layout()
    figures.append(fig1)

    # 🥧 Diagramme circulaire Windows 11
    total = win10 + win11
    if total > 0:
        fig2, ax2 = plt.subplots()
        ax2.pie(
            [win10, win11],
            labels=["Windows 10", "Windows 11"],
            colors=["skyblue", "limegreen"],
            autopct=make_autopct([win10, win11]),
            explode=(0.05, 0.1),
            shadow=True,
            startangle=140
        )
        ax2.set_title("Migration vers Windows 11")
        ax2.axis("equal")
        fig2.tight_layout()
        figures.append(fig2)

    # 🥧 Stat circulaire par région
    for region, data in stats_regions.items():
        total_region = data['win10'] + data['win11']
        if total_region > 0:
            fig_r, ax_r = plt.subplots()
            ax_r.pie(
                [data['win10'], data['win11']],
                labels=["Windows 10", "Windows 11"],
                colors=["skyblue", "limegreen"],
                autopct=make_autopct([data['win10'], data['win11']]),
                explode=(0.05, 0.1),
                shadow=True,
                startangle=140
            )
            ax_r.set_title(f"Migration vers Windows 11 - Région {region}")
            ax_r.axis("equal")
            fig_r.tight_layout()
            figures.append(fig_r)

    # 📝 Affichage du nombre de Win10/Win11 par numéro (colonne A)
    if win10_par_num or win11_par_num:
        txt = "\nNombre d'ordinateurs Win10/Win11 par numéro (colonne A) :\n"
        for numero in sorted(set(list(win10_par_num.keys()) + list(win11_par_num.keys()))):
            n10 = win10_par_num.get(numero, 0)
            n11 = win11_par_num.get(numero, 0)
            txt += f"Numéro {numero} : Win10 = {n10}, Win11 = {n11}\n"
        fig_txt, ax_txt = plt.subplots(figsize=(6, 4))
        ax_txt.axis('off')
        ax_txt.text(0, 1, txt, va='top', ha='left', fontsize=10, family='monospace')
        fig_txt.tight_layout()
        figures.append(fig_txt)

    # 🥧 Stat circulaire par numéro (colonne A)
    numeros = sorted(set(list(win10_par_num.keys()) + list(win11_par_num.keys())))
    for numero in numeros:
        n10 = win10_par_num.get(numero, 0)
        n11 = win11_par_num.get(numero, 0)
        if n10 + n11 > 0:
            fig_num, ax_num = plt.subplots()
            ax_num.pie(
                [n10, n11],
                labels=["Windows 10", "Windows 11"],
                colors=["skyblue", "limegreen"],
                autopct=make_autopct([n10, n11]),
                explode=(0.05, 0.1),
                shadow=True,
                startangle=140
            )
            ax_num.set_title(f"Migration Win10/Win11 - Numéro {numero}")
            ax_num.axis("equal")
            fig_num.tight_layout()
            figures.append(fig_num)

    # Stat globale à la fin si stats_globales est fourni
    if stats_globales:
        txt = "\n=== Statistiques Globales ===\n"
        txt += f"Nombre total de fichiers : {stats_globales['nb_fichiers']}\n"
        txt += f"Total portables : {stats_globales['total_portables']}\n"
        txt += f"Total fixes : {stats_globales['total_fixes']}\n"
        txt += f"Total Win10 : {stats_globales['total_win10']}\n"
        txt += f"Total Win11 : {stats_globales['total_win11']}\n"
        txt += f"Total régions : {len(stats_globales['regions'])}\n"
        txt += f"Total numéros : {len(stats_globales['numeros'])}\n"
        fig_global, ax_global = plt.subplots(figsize=(6, 4))
        ax_global.axis('off')
        ax_global.text(0, 1, txt, va='top', ha='left', fontsize=12, fontweight='bold', family='monospace')
        fig_global.tight_layout()
        figures.append(fig_global)

    # Affichage dans une fenêtre avec navigation
    GraphViewer(root, figures)

def lire_colonne_a(sheet):
    i = 1
    numeros_lus = []
    while True:
        cell_a = f"A{i}"
        try:
            valeur_a = str(sheet.Range[cell_a].Value).strip()
        except:
            break
        if valeur_a == "":
            break
        numeros = re.findall(r'\d+', valeur_a)
        if numeros:
            numeros_lus.append(numeros[0])
        i += 1
    return numeros_lus

def traiter_fichier(fichier_excel, progressbar, root, stats_globales=None, titre_fichier=None, callback=None):
    progressbar.start()
    try:
        wb = Workbook()
        wb.LoadFromFile(fichier_excel)
        sheet = wb.Worksheets[0]

        numeros_lus = lire_colonne_a(sheet)

        ordi = ["Probook", "2475AC9", "2475A37", "Latitude E6530", "Latitude e5530",
                "Latitude E6540", "HP ProBook 6570b"]

        mois_portables = {}
        mois_fixes = {}
        ordiportable = 0
        ordifixe = 0
        serv4110 = 0
        serv4111 = 0
        i = 1

        stats_regions = {}
        win10_par_num = {}
        win11_par_num = {}

        while True:
            cell_a = f"A{i}"
            cell_c = f"C{i}"
            cell_f = f"F{i}"
            cell_d = f"D{i}"
            try:
                valeur_a = str(sheet.Range[cell_a].Value).strip()
                valeur_c = str(sheet.Range[cell_c].Value).strip()
                valeur_f = str(sheet.Range[cell_f].Value).strip()
                valeur_d = str(sheet.Range[cell_d].Value).strip().lower()
            except:
                break

            if valeur_c == "":
                break

            match = re.match(r"(\d{2})/(\d{2})/\d{4}", valeur_f)
            mois = match.group(2) if match else None

            numeros = re.findall(r'\d+', valeur_a)
            numero = numeros[0] if numeros else None

            if any(mot in valeur_c for mot in ordi):
                ordiportable += 1
                if mois:
                    mois_portables[mois] = mois_portables.get(mois, 0) + 1
            else:
                ordifixe += 1
                if mois:
                    mois_fixes[mois] = mois_fixes.get(mois, 0) + 1

            if numero:
                if "win 10" in valeur_d:
                    win10_par_num[numero] = win10_par_num.get(numero, 0) + 1
                elif "win 11" in valeur_d:
                    win11_par_num[numero] = win11_par_num.get(numero, 0) + 1

            i += 1

        win10 = 0
        win11 = 0
        i9 = 1
        while True:
            cell_win = f"D{i9}"
            cell_serv = f"A{i9}"
            try:
                valeur_win = str(sheet.Range[cell_win].Value).strip().lower()
                valeur_serv = str(sheet.Range[cell_serv].Value).strip()
            except:
                break

            if valeur_win == "":
                break

            if "win 10" in valeur_win:
                win10 += 1
            elif "win 11" in valeur_win:
                win11 += 1

            region_match = re.search(r'\b(0\d{3}|[1-9]\d{3})\b', valeur_serv)
            if region_match:
                region_code = region_match.group(0)
                if region_code not in stats_regions:
                    stats_regions[region_code] = {'win10': 0, 'win11': 0}
                if "win 10" in valeur_win:
                    stats_regions[region_code]['win10'] += 1
                elif "win 11" in valeur_win:
                    stats_regions[region_code]['win11'] += 1

            i9 += 1

        mois_uniques = sorted(set(mois_portables) | set(mois_fixes))
        valeurs_portables = [mois_portables.get(m, 0) for m in mois_uniques]
        valeurs_fixes = [mois_fixes.get(m, 0) for m in mois_uniques]

        # Mise à jour des stats globales si fourni
        if stats_globales is not None:
            stats_globales['total_portables'] += ordiportable
            stats_globales['total_fixes'] += ordifixe
            stats_globales['total_win10'] += win10
            stats_globales['total_win11'] += win11
            stats_globales['regions'].update(stats_regions.keys())
            stats_globales['numeros'].update(win10_par_num.keys())
            stats_globales['numeros'].update(win11_par_num.keys())

        root.after(0, afficher_graphiques, mois_uniques, valeurs_portables, valeurs_fixes, win10, win11, stats_regions, win10_par_num, win11_par_num, titre_fichier, stats_globales if callback is None else None)

        if callback:
            callback()

    except Exception as e:
        messagebox.showerror("Erreur", f"Erreur lors du traitement :\n{e}")
        if callback:
            callback()
    finally:
        progressbar.stop()
        progressbar.grid_remove()
        root.config(cursor="")

def traiter_dossier(dossier, progressbar, root):
    fichiers = [os.path.join(dossier, f) for f in os.listdir(dossier) if f.lower().endswith(('.xlsx', '.xls'))]
    if not fichiers:
        messagebox.showinfo("Aucun fichier", "Aucun fichier Excel trouvé dans ce dossier.")
        progressbar.grid_remove()
        root.config(cursor="")
        return

    stats_globales = {
        'nb_fichiers': len(fichiers),
        'total_portables': 0,
        'total_fixes': 0,
        'total_win10': 0,
        'total_win11': 0,
        'regions': set(),
        'numeros': set()
    }

    def traiter_suivant(index=0):
        if index < len(fichiers):
            fichier = fichiers[index]
            traiter_fichier(
                fichier,
                progressbar,
                root,
                stats_globales=stats_globales,
                titre_fichier=os.path.basename(fichier),
                callback=lambda: traiter_suivant(index + 1)
            )
        else:
            # Afficher la grande stat globale à la fin
            root.after(0, lambda: afficher_graphiques(
                [], [], [], 0, 0, {}, {}, {},
                titre_fichier="Statistiques Globales",
                stats_globales=stats_globales
            ))

    traiter_suivant(0)

def choisir_fichier():
    fichier = filedialog.askopenfilename(
        title="Sélectionner le fichier Excel",
        filetypes=[("Fichiers Excel", "*.xlsx *.xls")]
    )
    if fichier:
        progressbar.grid(row=2, column=0, pady=(10, 0))
        root.config(cursor="watch")
        threading.Thread(target=traiter_fichier, args=(fichier, progressbar, root)).start()

def choisir_dossier():
    dossier = filedialog.askdirectory(
        title="Sélectionner un dossier contenant des fichiers Excel"
    )
    if dossier:
        progressbar.grid(row=2, column=0, pady=(10, 0))
        root.config(cursor="watch")
        threading.Thread(target=traiter_dossier, args=(dossier, progressbar, root)).start()

# 🎨 Interface Tkinter
root = tk.Tk()
root.title("Renouvellement PC 2025")

tk.Label(root, text="Bienvenue 👋").grid(row=0, column=0, pady=(15, 5))
frame_btn = tk.Frame(root)
frame_btn.grid(row=1, column=0, padx=20, pady=10)
tk.Button(frame_btn, text="📂 Choisir le fichier Excel", command=choisir_fichier).pack(side=tk.LEFT, padx=5)
tk.Button(frame_btn, text="📁 Choisir un dossier", command=choisir_dossier).pack(side=tk.LEFT, padx=5)

progressbar = ttk.Progressbar(root, mode='indeterminate', length=220)
progressbar.grid(row=2, column=0, pady=(10, 20))
progressbar.grid_remove()

root.mainloop()

# by Celestin Lallement © 2025